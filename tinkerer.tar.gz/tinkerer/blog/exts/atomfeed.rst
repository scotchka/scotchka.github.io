.. _atomfeed:

Atom Feed
=========

Tinkerer can now generate Atom feeds with the Atom feed extension contributed
by Sean Gillies.

The extension is available on `PyPI <https://pypi.python.org/pypi/rutherford/>`_ 
or you can get it from its `GitHub repo <https://github.com/sgillies/rutherford>`_.

