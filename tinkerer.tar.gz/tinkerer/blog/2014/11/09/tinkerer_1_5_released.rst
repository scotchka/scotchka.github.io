Tinkerer 1.5 Released
=====================

What's New
----------

* Support for custom landing page with new ``landing_page`` option in
  ``conf.py`` (see :ref:`landingpage`)
* Ability to rename *"Home"* to a custom string with ``conf.py`` setting
  (see :ref:`landingpage`)
* Moved up to minimum supported Sphinx version 1.2.3. Support for Sphinx
  1.3b.
* Slovak localization
* Numerous bug fixes

Acknowledgments
---------------

As always, much of this is owed to `the contributors <https://github.com/vladris/tinkerer/blob/master/CONTRIBUTORS>`_.

.. author:: default
.. categories:: tinkerer
.. tags:: tinkerer, release
.. comments::
