Tinkerer 1.3 Released
=====================

What's New
----------

* Brazilian Portuguese localization
* Russian localization
* Simplified Chinese localization
* Traditional Chinese localization
* Tinkerer now uses the Babel package for date formatting
* Other bug fixes

Aknowledgments
--------------

As always, many thanks to the community for the great work!

.. author:: default
.. categories:: tinkerer
.. tags:: tinkerer, release
.. comments::
