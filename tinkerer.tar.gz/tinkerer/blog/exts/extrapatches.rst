Patch Extra
===========
.. highlight:: python

Additional patches for nicer HTML output.

Simply add it to your extensions in ``conf.py``: ::

  # Add other Sphinx extensions here
  extensions = [..., 'patch_extra']
