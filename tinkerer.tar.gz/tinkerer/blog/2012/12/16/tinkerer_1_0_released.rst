Tinkerer 1.0 Released
=====================

Out of Beta
-----------

After one year, Tinkerer is finally going out of Beta! Thanks to everyone who
helped out by trying Tinkerer out, opening bugs or fixing them. This is a big
milestone for the project.

What's New
----------

* Updated `HTML5 Boilerplate <http://html5bolierplate.com>`_ base template
* New *Responsive* theme
* ``--preview`` command line argument enabling draft preview
* ``--date`` command line argument for specifying post dates (useful when 
  writing a script for migrating from your previous crappy blogging engine
  to Tinkerer)
* French, Japanese, Polish and UK English localizations
* Many bug fixes

.. author:: default
.. categories:: tinkerer
.. tags:: tinkerer, release
.. comments::
