{{ title }}
{% for _ in title %}={% endfor %}

{{ content }}

.. author:: {{ author }}
.. categories:: {{ categories }}
.. tags:: {{ tags }}
.. comments::

