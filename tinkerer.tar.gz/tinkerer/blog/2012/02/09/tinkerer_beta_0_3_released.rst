Tinkerer 0.3 Beta Released
==========================

What's New
----------

* Tinkerer went international! Spanish and Catalan translations are now 
  available. To have your Tinkerer blog displayed in Spanish, add the 
  following line to your ``conf.py``::

    language = "es"

  For Catalan, add::

    language = "ca"

* Limited support for Facebook comments as an alternative to Disqus comments
* RSS feed enhancements: RSS feed auto-discovery and feed categories
* Multiple bugfixes and minor style tweaks to the Modern theme

.. author:: default
.. categories:: tinkerer
.. tags:: tinkerer, release
.. comments::

