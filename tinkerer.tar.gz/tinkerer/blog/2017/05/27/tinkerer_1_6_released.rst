Tinkerer 1.6 Released
=====================

What's New
----------

* The most important change with this release is moving minimum supported Sphinx
  version 1.6.1. Tinkerer was relying on a Sphinx implementation detail which
  changed with the 1.6.1 release. This update addresses the issue.
* Minor layout change to the archive page in the flat theme
* Support Disqus over both HTTP and HTTPS
* Other minor changes and bug fixes

Acknowledgments
---------------

Many thanks to the awesome `contributors <https://github.com/vladris/tinkerer/blob/master/CONTRIBUTORS>`_!

.. author:: default
.. categories:: tinkerer
.. tags:: tinkerer, release
.. comments::
