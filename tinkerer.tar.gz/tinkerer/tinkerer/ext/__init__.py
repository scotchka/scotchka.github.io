'''
    tinkerer.ext
    ~~~~~~~~~~~~

    Blogging extensions.

    :copyright: Copyright 2011-2018 by Vlad Riscutia and contributors (see
    CONTRIBUTORS file)
    :license: FreeBSD, see LICENSE file
'''
