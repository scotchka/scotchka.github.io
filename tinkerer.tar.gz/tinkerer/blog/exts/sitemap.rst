Sitemap
=======

Generate a ``sitemap.xml`` for the pages and posts.

Simply add it to your extensions in ``conf.py``: ::

    # Add other Sphinx extensions here
    extensions = [..., "sitemap"]
