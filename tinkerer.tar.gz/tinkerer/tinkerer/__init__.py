'''
    Tinkerer Blog
    ~~~~~~~~~~~~~

    Blogging with Sphinx. Like a boss.

    :copyright: Copyright 2011-2018 by Vlad Riscutia and contributors (see
    CONTRIBUTORS file)
    :license: FreeBSD, see LICENSE file
'''
__version__ = "1.7.0"

master_doc = "master"
source_suffix = ".rst"
